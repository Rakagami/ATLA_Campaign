
# Stress Management Moves
#firebending #stressmanagement

- **Level 1: Cool Down**
  - **Action:** Bonus Action.
  - **Range:** Self.
  - **Duration:** Instantaneous.
  - Reduce stress points by 2.
  - Focus your inner fire to calm your mind and regain clarity.

- **Level 3: Rage Fuel (Secret Technique)**
  - **Action:** Bonus Action.
  - **Range:** Self.
  - **Duration:** 3 rounds.
  - Transform your stress penalty into a bonus. For every stress point, gain a +1 to accuracy and damage rolls for the duration. At the end of the effect, stress resets to 0.
  - Unleash the power of your rage, turning your inner turmoil into devastating strength.
