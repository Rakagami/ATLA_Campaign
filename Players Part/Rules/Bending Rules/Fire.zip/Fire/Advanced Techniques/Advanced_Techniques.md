
# Advanced Techniques
#firebending #advanced

- **Blazing Phoenix**
  - *Action*: Channel your inner energy to create a massive phoenix of fire. It flies in a straight line for 60 feet, dealing 4d10 fire damage to all creatures in its path. The phoenix's trail burns for 3 rounds, dealing 1d6 fire damage to creatures entering it.

- **Firestorm**
  - *Action*: Create a localized storm of fire in a 20-foot radius. All creatures in the area must make a Dexterity saving throw or take 5d10 fire damage. The area burns for 2 rounds, dealing 1d8 fire damage per turn.

- **Combustion Blast**
  - *Action*: Focus intensely on a single point. After 2 rounds, unleash a massive explosion. All creatures within 30 feet of the point must make a Constitution saving throw or take 6d10 fire damage.
