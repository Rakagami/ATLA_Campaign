
# Blazing Phoenix
#firebending #advanced #level4

- **Level 4: Blazing Phoenix**
- Use at Least 4 [[Firebending Slot]]
  - **Action:** 1 Action.
  - **Range:** 3 * [[Firebending Slot]] meters.
  - **Duration:** Instantaneous.
  - **Damage:** [[Firebending Slot]]]] * 2 d10 fire.
  - Summon a massive phoenix of fire that flies in a straight line, damaging all in its path.
  - **Lingering Effect:** The phoenix's trail burns for 3 rounds.

**Links:**
- [[Firebending Slot]]
- [[_Firebending Moves]]
- [[Firebending DC]]

Tags:
#Firebending #Damage #Advanced
