# Core Attributes of Firebending
#firebending #coreattributes

- **Primary Stat**: Wisdom
  - Firebenders rely on their inner focus, discipline, and clarity to control their flames.

- **Key Mechanic**: Lingering Damage
  - Firebenders create residual damage zones where their fire strikes, representing burning or smoldering terrain.

- **Stress Level**: Firebenders gain a stress level counter, starting at 0. Stress increases by 1 each time the firebender is hit by an attack. For every [[Stress Level]] the Firebender suffers -1 to attack and damage Rolls. At high levels, stress can be managed or turned into a weapon.
