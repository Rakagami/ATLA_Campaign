
# Explosive Firebending
#firebending #style #explosive

- Focuses on powerful area-of-effect attacks.
- **Move: Fireburst**
  - *Action*: Target a point within 30 feet. All creatures in a 10-foot radius must make a Dexterity saving throw or take 3d6 fire damage.
  - *Lingering Effect*: The area burns for 2 rounds, dealing 1d4 fire damage to creatures starting their turn there.
