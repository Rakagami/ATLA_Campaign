
# Agni Kai Style
#firebending #style #agnikai

- Duels emphasize precision and dominance.
- **Move: Burning Duel**
  - *Action*: Choose a single target and engage them in a duel. Both you and the target gain +2 to attack rolls against each other until one is incapacitated.
  - *Lingering Effect*: The ground around you is superheated; creatures entering the area take 1d6 fire damage.
