
# Dancing Dragon Style
#firebending #style #dancingdragon

- Focuses on fluid, continuous motion.
- **Move: Spiral Flames**
  - *Action*: Spin and release flames in a 360-degree arc. Creatures within 10 feet must make a Dexterity saving throw or take 2d6 fire damage.
  - *Lingering Effect*: The area smolders, imposing disadvantage on Dexterity saving throws for creatures within it until the start of your next turn.
