
# Classic Firebending
#firebending #style #classic

- Focuses on powerful, straightforward attacks.
- **Move: [[Flame Jet]]
