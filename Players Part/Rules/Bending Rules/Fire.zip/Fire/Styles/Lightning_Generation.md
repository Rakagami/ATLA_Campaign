
# Lightning Generation
#firebending #style #lightning

- Rare skill requiring intense focus.
- **Move: Lightning Strike**
  - *Action*: Spend 2 turns charging and unleash a precise bolt of lightning. One target within 60 feet must make a Constitution saving throw or take 4d10 lightning damage. On a successful save, they take half damage.
  - *Lingering Effect*: None, but the charge must be used within the next turn.
