
# Level 4 Moves
#firebending #level4

- **Lightning Strike**
  - **Action:** 2 Actions (Charge required).
  - **Range:** 30 * [[Firebending Slot]] meters.
  - **Duration:** Instantaneous.
  - **Damage:** 4d10 lightning.
  - **Attack Roll:** [[Wisdom]] + [[Proficiency]].
  - After charging for a round, unleash a bolt of lightning at a single target.

- **Blazing Phoenix**
  - **Action:** 1 Action.
  - **Range:** 30 * [[Firebending Slot]] meters.
  - **Duration:** Instantaneous.
  - **Damage:** 4d10 fire.
  - Summon a massive phoenix of fire that flies in a straight line, damaging all in its path.
  - **Lingering Effect:** The phoenix's trail burns for 3 rounds, dealing 1d6 fire damage to creatures entering it.

- **Firestorm**
  - **Action:** 1 Action.
  - **Range:** 20-foot radius.
  - **Duration:** Instantaneous.
  - **Damage:** 5d10 fire.
  - Create a localized storm of fire in a 20-foot radius, damaging all creatures within the area.
  - **Lingering Effect:** The area burns for 2 rounds, dealing 1d8 fire damage per turn.
