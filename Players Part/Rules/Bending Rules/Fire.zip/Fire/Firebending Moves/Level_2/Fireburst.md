
  - **Action:** 1 Action.
  - **Range:** 5 * [[Firebending Slot]] meters. Sphere with a radius of [[Firebending Slot]] * 1 meters.
  - **Duration:** Instantaneous.
  - **Damage:** 2d6 fire per [[Firebending Slot]].
  - **Save:** Dex DC against your  [[Firebending DC]] 
  - Create a fiery explosion at a target point, affecting all creatures within a 10-foot radius.
  - **Lingering Effect:** The area burns for 2 rounds.


#firebending #level2 #Lingering_Effect