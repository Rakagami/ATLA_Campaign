
#firebending #level2
  - **Action:** 1 Action.
  - **Range:** 2 * [[Firebending Slot]] metercone.
  - **Duration:** Instantaneous.
  - **Damage:** 2*[[Firebending Slot]]d6 fire.
  - Unleash a wide wave of flames, forcing creatures in the cone to make a Dexterity saving throw or take full damage.
