

  - **Action:** 1 Action.
  - **Range:** 1 * [[Firebending Slot]] meters.
  - **Duration:** Instantaneous.
  - **Damage:** [[Firebending Slot]]* 2d8 fire.
  - **Attack Roll:** [[Wisdom]] + [[Proficiency]].
  - Release multiple smaller blasts of fire in quick succession, targeting up to three creatures within range.

#firebending #level2