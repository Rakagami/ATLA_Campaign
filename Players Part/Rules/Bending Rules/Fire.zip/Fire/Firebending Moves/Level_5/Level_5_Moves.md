
# Level 5 Moves
#firebending #level5

- **Volcanic Eruption**
  - **Action:** 1 Action.
  - **Range:** 40 * [[Firebending Slot]] meters.
  - **Duration:** Instantaneous.
  - **Damage:** 6d10 fire.
  - Create a massive eruption of molten rock and fire at a target point, affecting all creatures in a 30-foot radius.

- **Meteor Shower**
  - **Action:** 2 Actions.
  - **Range:** 50 * [[Firebending Slot]] meters.
  - **Duration:** 3 rounds.
  - Summon fiery meteors that fall in a 50-foot radius. Each round, creatures in the area must make Dexterity saving throws or take 4d6 fire damage.

- **Infernal Form**
  - **Action:** Bonus Action.
  - **Range:** Self.
  - **Duration:** 1 minute.
  - Transform into a being of pure flame. Gain resistance to all non-magical damage and deal 2d8 fire damage to any creature that attacks you in melee.
