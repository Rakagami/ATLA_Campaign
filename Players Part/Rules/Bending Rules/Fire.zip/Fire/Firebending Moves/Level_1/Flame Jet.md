#firebending #level1

- **[[Flame Jet]]**
  - **Action:**  #Action.
  - **Range:** 5 * [[Firebending Slot]] meters.
  - **Damage:**   [[Firebending Slot]] * 1 d10 fire
  - **Attack Roll:** [[Wisdom]] + [[Proficiency]].
  - Unleash a burst of flames in a straight line, damaging all targets in its path.
  - [[Lingering Effect]]
