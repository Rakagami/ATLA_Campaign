- **[[Burning Fists]]
  - **Action:** #Action.
  - **Range:** melee.

  - Attack Roll: Attacks [[Firebending Slot]] times with [[Strength]] + [[Proficiency]].
  - Damage: 1d6 + [[Strength]] Bludgeoning + 1d12 fire
  - Lingering Effect: This Effect moves with the creature. Therefore it cannot be moved put of but can be extinguished or nullified in other ways. 


#firebending #level1