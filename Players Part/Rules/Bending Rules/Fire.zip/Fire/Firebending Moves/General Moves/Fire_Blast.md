
# Fire Blast
#firebending #moves #level1

- **Level 1: Fire Blast**
  - **Action:** 1 Action.
  - **Range:** 10 meters.
  - **Duration:** Instantaneous.
  - **Damage:** 1d8 fire.
  - **Attack Roll:** [[Wisdom]] + [[Proficiency]].
  - Launch a ball of fire at a single target.
  - **[[Lingering Effect]]

**Links:**
- [[Firebending Slot]]
- [[_Firebending Moves]]
- [[Firebending DC]]

Tags:
#Firebending #Damage
