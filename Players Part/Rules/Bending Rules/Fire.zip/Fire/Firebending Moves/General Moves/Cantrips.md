
# Cantrip Firebending Moves
#firebending #moves

- **[[Fire_Blast]]**

- **Flame Shield**
  - #Reaction: Create a shield of fire, granting 2 [[Evasion]] against a single attack. If the attack is melee and misses, the attacker takes 1d8 fire damage.

- **Ignite Terrain**
  - #Action: Set fire to a 1 meter radius sphere area of terrain within 20 feet. The fire lasts 3 rounds and deals 1d6 fire damage to creatures entering or starting their turn in the area.

- **Intimidating Flame**
  - #Bonus_Action: Manipulate your fire to intimidate nearby creatures. Targets within 2 Meter must make a Wisdom saving throw or become frightened until the end of your next turn.
