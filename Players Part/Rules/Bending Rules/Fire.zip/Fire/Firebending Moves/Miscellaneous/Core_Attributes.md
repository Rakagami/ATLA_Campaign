
# Core Attributes of Firebending
#firebending #coreattributes

- **Primary Stat**: Wisdom
  - Firebenders rely on their inner focus, discipline, and clarity to control their flames.
- **Key Mechanic**: Lingering Damage
  - Firebenders create residual damage zones where their fire strikes, representing burning or smoldering terrain.
- **Stress Level**: Firebenders gain a stress level counter, starting at 0. Stress increases by 1 each time the firebender is hit by an attack. If the stress level exceeds 5, the firebender suffers a -2 penalty to accuracy rolls. At high levels, stress can be managed or turned into a weapon.
