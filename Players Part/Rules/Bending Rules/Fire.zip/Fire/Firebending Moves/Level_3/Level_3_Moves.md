
# Level 3 Moves
#firebending #level3

- **Scorching Aura**
  - **Action:** Bonus Action.
  - **Range:** Self.
  - **Duration:** 3 rounds.
  - Creatures within 5 feet of you take 1d6 fire damage at the start of their turn.

- **Heat Mirage**
  - **Action:** 1 Action.
  - **Range:** 30 * [[Firebending Slot]] meters.
  - **Duration:** 1 round.
  - Create a mirage of heat, imposing disadvantage on attack rolls for creatures within a 10-foot radius of a point you choose.

- **Rage Fuel**
  - **Action:** Bonus Action.
  - **Range:** Self.
  - **Duration:** 3 rounds.
  - Transform your stress penalty into a bonus. Gain +1 to accuracy and damage rolls for every stress point. At the end, stress resets to 0.
